"""Compose RTC-only generated PAC changes and the Embassy low-power candidate."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys

from rtc_ir import ROOT, FAMILIES

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'xtask/scripts'))
import peripheral_matrix as pm


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Patch context is not unique: ' + old[:80])
    return text.replace(old, new, 1)


def rtc_span(text):
    matches = list(re.finditer(r'Peripheral\s*\{\s*name:\s*"RTC",', text))
    assert len(matches) == 1
    start = matches[0].start()
    depth = 0
    for index in range(text.index('{', start), len(text)):
        if text[index] == '{':
            depth += 1
        elif text[index] == '}':
            depth -= 1
            if depth == 0:
                return start, index + 1
    raise ValueError('Unterminated RTC peripheral')


def formatted(raw):
    return subprocess.check_output(['rustfmt', '+1.98.1', '--edition', '2024', '--emit', 'stdout'], input=raw).decode().replace('\r\n', '\n')


def run(out, resume=False):
    if resume:
        assert (out / 'failure.json').is_file() and not (out / 'validation.json').exists()
    else:
        out.mkdir(exist_ok=False)
    generated = HERE / 'generation-v2'
    gen_record = json.loads((generated / 'validation.json').read_bytes())
    assert gen_record['completed']
    for p, digest in gen_record['sources'].items():
        assert pm.sha(Path(p)) == digest, p
    for p, digest in gen_record['outputs'].items():
        assert pm.sha(generated / p) == digest, p
    fields = json.loads((HERE / 'fields-v1/validation.json').read_bytes())
    assert fields['completed'] and fields['passed_tests'] == 36
    pm.ensure_snapshot(fields['sources'])
    pm.ensure_snapshot(fields['artifacts'])
    source_pac, source_hal = ROOT / 'vendor/stm32-metapac', ROOT / 'vendor/embassy-stm32'
    trees = pm.tree_snapshot([source_pac, source_hal])
    pac, hal = out / 'stm32-metapac', out / 'embassy-stm32'
    for source, dest in [(source_pac, pac), (source_hal, hal)]:
        for name in trees[str(source)]:
            p = dest / name
            p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / name, p)
    generated_pac = generated / 'build/stm32-metapac'
    versions = []
    for family in FAMILIES:
        die = '47c' if family in FAMILIES[:2] else '47a'
        version = 'v3_' + family.lower() + '_' + die
        versions.append(version)
        for folder in ['peripherals', 'registers']:
            relative = Path('src') / folder / ('rtc_' + version + '.rs')
            (pac / relative).write_text(formatted((generated_pac / relative).read_bytes()), encoding='utf-8', newline='\n')
    applied = {}
    for chip in gen_record['chips']:
        name = chip.lower()
        generated_chip = generated_pac / 'src/chips' / name / 'metadata.rs'
        generated_meta = (generated_chip.parent / re.search(r'include!\("([^"]+)"\)', generated_chip.read_text(encoding="utf-8"))[1]).resolve()
        reference = formatted(generated_meta.read_bytes())
        a, b = rtc_span(reference)
        new_rtc = reference[a:b]
        version = re.search(r'version: "([^"]+)"', new_rtc)[1]
        old_version = version.removeprefix('v3_')
        selected_chip = pac / 'src/chips' / name / 'metadata.rs'
        selected_meta = (selected_chip.parent / re.search(r'include!\("([^"]+)"\)', selected_chip.read_text(encoding="utf-8"))[1]).resolve()
        assert selected_meta.is_relative_to(pac)
        # Shared metadata must give identical RTC peripheral definitions for
        # every chip referencing it. All unrelated source bytes are retained.
        if selected_meta in applied:
            assert applied[selected_meta] == new_rtc
        else:
            text = selected_meta.read_text(encoding="utf-8")
            x, y = rtc_span(text)
            text = text[:x] + new_rtc + text[y:]
            text = replace_once(text, f'../registers/rtc_{old_version}.rs', f'../registers/rtc_{version}.rs')
            selected_meta.write_text(text, encoding='utf-8', newline='\n')
            applied[selected_meta] = new_rtc
        chip_pac = pac / 'src/chips' / name / 'pac.rs'
        text = replace_once(chip_pac.read_text(encoding="utf-8"), f'../../peripherals/rtc_{old_version}.rs', f'../../peripherals/rtc_{version}.rs')
        chip_pac.write_text(text, encoding='utf-8', newline='\n')
    inventory = pac / 'src/all_peripheral_versions.rs'
    text = inventory.read_text(encoding="utf-8")
    matches = list(re.finditer(r'\("rtc",\s*&\[', text))
    if not matches:
        matches = list(re.finditer(r'\(\s*"rtc",\s*&\[', text))
    assert len(matches) == 1
    offset = matches[0].end()
    text = text[:offset] + ''.join('\n        "' + v + '",' for v in versions) + text[offset:]
    inventory.write_text(text, encoding='utf-8', newline='\n')
    build = hal / 'build.rs'
    build.write_text(replace_once(build.read_text(encoding="utf-8"), '"sbs" | "otg"', '"sbs" | "otg" | "rtc"'), encoding='utf-8', newline='\n')
    stop_source = ROOT / 'target/h5-stop-restore-v1/stage/embassy-stm32/src/low_power.rs'
    stop = stop_source.read_text(encoding="utf-8")
    stop = replace_once(stop, '        #[cfg(stm32h5)]\n        crate::pac::PWR.pmcr().modify(|v| {',
        '        #[cfg(all(stm32h5, not(any(stm32h5_47a, stm32h5_47c))))]\n        crate::pac::PWR.pmcr().modify(|v| {')
    anchor = '            v.set_svos(vals::Svos::Scale3);\n        });'
    stop = replace_once(stop, anchor, anchor + '\n        #[cfg(any(stm32h5_47a, stm32h5_47c))]\n        crate::pac::PWR.pmcr().modify(|v| {\n            // Exact H5 PMCR: LPMS=0 selects Stop; SVOS=3 selects scale 3.\n            v.set_lpms(false);\n            v.set_svos(3);\n        });')
    (hal / 'src/low_power.rs').write_text(stop, encoding='utf-8', newline='\n')
    rtc_low = hal / 'src/rtc/low_power.rs'
    text = rtc_low.read_text(encoding="utf-8")
    text = replace_once(text, '#[cfg(not(any(stm32u5, stm32u3, stm32u0, stm32wba)))]',
                        '#[cfg(not(any(stm32u5, stm32u3, stm32u0, stm32wba, stm32h5_47a, stm32h5_47c)))]')
    text = replace_once(text, '            EXTI.rtsr(0).modify(|w| w.set_line(RTC::EXTI_WAKEUP_LINE, true));',
                        '            // H5 RTC uses direct EXTI line 17; RTSR1 only has lines 0..16.\n            #[cfg(not(stm32h5))]\n            EXTI.rtsr(0).modify(|w| w.set_line(RTC::EXTI_WAKEUP_LINE, true));')
    anchor = '        #[cfg(stm32u5)]\n        {\n            use crate::pac::RCC;'
    text = replace_once(text, anchor, '        #[cfg(any(stm32h5_47a, stm32h5_47c))]\n        {\n            crate::pac::EXTI.imr1().modify(|w| w.set_im17(true));\n        }\n' + anchor)
    rtc_low.write_text(text, encoding='utf-8', newline='\n')
    sources = {str(Path(base) / name): digest for base, files in trees.items() for name, digest in files.items()}
    sources.update(gen_record['sources'])
    sources.update(fields['sources'])
    for p in [Path(__file__), stop_source, generated / 'validation.json', HERE / 'fields-v1/validation.json']:
        sources[str(p)] = pm.sha(p)
    changes = {}
    for original_tree, staged in [(source_pac, pac), (source_hal, hal)]:
        files = pm.tree_snapshot([staged])[str(staged)]
        before = trees[str(original_tree)]
        assert not (before.keys() - files.keys())
        changes[staged.name] = dict(added=sorted(files.keys() - before.keys()), changed=sorted(n for n in before if files[n] != before[n]))
        sources.update({str(staged / name): digest for name, digest in files.items()})
    assert changes['embassy-stm32']['changed'] == ['build.rs', 'src/low_power.rs', 'src/rtc/low_power.rs']
    assert len(changes['stm32-metapac']['added']) == 12
    pm.ensure_snapshot(sources)
    pm.write_json(out / 'sources.json', sources)
    pm.write_json(out / 'validation.json', dict(completed=True, integrated=False, hil='not-run',
        scope='Isolated PAC/HAL source preparation; ARM compilation not yet run', chips=gen_record['chips'], changes=changes,
        sources=dict(path=str(out / 'sources.json'), sha256=pm.sha(out / 'sources.json'), files=len(sources))))
    print('Prepared 38-chip RTC/STOP candidate; source files bound:', len(sources), flush=True)


if __name__ == '__main__':
    run(Path(sys.argv[1]).resolve(), sys.argv[2:] == ['--resume-preparation'])
