"""Generate exact RTC interfaces with the pinned, unchanged metapac generator."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

from rtc_ir import ROOT, FAMILIES, adapt, original

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'data/patches/stm32h5-47c-pac'))
import provenance


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def run(out):
    out.mkdir(exist_ok=False)
    prior = json.loads((HERE / 'input-audit-v1/validation.json').read_bytes())
    assert prior['completed'] and len(prior['families']) == 6
    for p, digest in {**prior['sources'], **prior['artifacts']}.items():
        assert sha(Path(p)) == digest, p
    sources = dict(prior['sources'])
    for name in ['generate.py', 'rtc_ir.py', 'test_ir.py', 'input-audit-v1/validation.json']:
        sources[str(HERE / name)] = sha(HERE / name)
    data = out / 'build/data'
    with zipfile.ZipFile(ROOT / 'data/patches/stm32h5-47a-pac/inputs.zip') as z:
        for name in z.namelist():
            if name.startswith('registers/') and name.endswith('.json'):
                p = (data / name).resolve()
                assert p.is_relative_to(data.resolve())
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(z.read(name))
    for p in (ROOT / 'data/patches/stm32h5-47c-pac/registers').glob('*.json'):
        target = data / 'registers' / p.name
        if target.exists():
            assert json.loads(target.read_bytes()) == json.loads(p.read_bytes()), p
        else:
            shutil.copyfile(p, target)
        sources[str(p)] = sha(p)
    versions = {}
    for family in FAMILIES:
        die = '47c' if family in FAMILIES[:2] else '47a'
        version = 'v3_' + family.lower() + '_' + die
        versions[family] = version
        constants = HERE / 'input-audit-v1' / family / 'constants.json'
        sources[str(constants)] = sha(constants)
        dump(data / 'registers' / ('rtc_' + version + '.json'), adapt(original(family), json.loads(constants.read_bytes())))
    chips = []
    for package in ['stm32h5-47a-pac', 'stm32h5-47c-pac']:
        for p in sorted((ROOT / 'data/patches' / package / 'chips').glob('*.json')):
            sources[str(p)] = sha(p)
            chip = json.loads(p.read_bytes())
            family = chip['line']
            assert family in FAMILIES
            rtc = next(p for p in chip['cores'][0]['peripherals'] if p['name'] == 'RTC')
            rtc['registers']['version'] = versions[family]
            # H5 non-secure RTC IRQ is 2; secure IRQ is 3. The framework's
            # supported configuration disables TrustZone. The ST H5E5 wakeup
            # sample and H553 RTC sample install RTC_IRQn.
            rtc['interrupts'] = [dict(signal='GLOBAL', interrupt='RTC'), dict(signal='WKUP', interrupt='RTC'),
                                 dict(signal='SECURE', interrupt='RTC_S')]
            rtc['rcc'] = dict(bus_clock='PCLK3', kernel_clock=dict(register='BDCR', field='RTCSEL'),
                              enable=dict(register='APB3ENR', field='RTCAPBEN'), stop_mode='Standby')
            dump(data / 'chips' / p.name, chip)
            chips.append(chip['name'])
    assert len(chips) == 38 and len(set(chips)) == 38
    binary, generator = provenance.generator(ROOT)
    log = out / 'generator.log'
    with log.open('wb') as output:
        subprocess.run([str(binary)], cwd=out, stdout=output, stderr=subprocess.STDOUT, check=True)
    rtc_modules = []
    for version in versions.values():
        p = out / 'build/stm32-metapac/src/peripherals' / ('rtc_' + version + '.rs')
        formatted = subprocess.check_output(['rustfmt', '+1.98.1', '--edition', '2024', '--emit', 'stdout'], input=p.read_bytes())
        p.write_bytes(formatted.replace(b'\r\n', b'\n'))
        rtc_modules.append(str(p))
    for p, digest in sources.items():
        assert sha(Path(p)) == digest, p
    dump(out / 'validation.json', dict(completed=True, integrated=False, hil='not-run', chips=chips,
         scope='PAC generation only; no ARM HAL build', sources=sources, generator=generator,
         rtc_modules={p: sha(Path(p)) for p in rtc_modules},
         outputs={p.relative_to(out).as_posix(): sha(p) for p in (out / 'build').rglob('*') if p.is_file()}))
    print('Generated exact RTC v3 interfaces for', len(chips), 'chips /', len(rtc_modules), 'native RTC variants', flush=True)


if __name__ == '__main__':
    run(Path(sys.argv[1]).resolve())
