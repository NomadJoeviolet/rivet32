"""Make the H5 low-power vector match the v3 RTC driver's non-secure IRQ."""
from pathlib import Path
import json
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'xtask/scripts'))
import peripheral_matrix as pm

prior = HERE / 'stage-v2'
out = HERE / 'stage-v3'
out.mkdir(exist_ok=False)
record = json.loads((prior / 'validation.json').read_bytes())
sources = json.loads(Path(record['sources']['path']).read_bytes())
pm.ensure_snapshot(sources)
old_hal = Path(record['hal'])
new_hal = out / 'embassy-stm32'
tree = pm.tree_snapshot([old_hal])[str(old_hal)]
for name in tree:
    p = new_hal / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(old_hal / name, p)
p = new_hal / 'src/low_power.rs'
s = p.read_text(encoding='utf-8')
old = '#[cfg(all(feature = "rt", not(any(stm32u0, feature = "_lp-time-driver"))))]'
assert s.count(old) == 1
s = s.replace(old, '#[cfg(all(feature = "rt", not(any(stm32u0, stm32h5, feature = "_lp-time-driver"))))]')
anchor = '#[cfg(all(feature = "rt", stm32u0))]'
assert s.count(anchor) == 1
s = s.replace(anchor, '// Match the H5 v3 driver\'s RTC WakeupInterrupt. Older metadata may\n// label the secure vector RTC_S, which does not serve this configuration.\n#[cfg(all(feature = "rt", stm32h5, not(feature = "_lp-time-driver")))]\n#[interrupt]\n#[allow(non_snake_case)]\nunsafe fn RTC() {}\n\n' + anchor)
p.write_text(s, encoding='utf-8', newline='\n')
after = pm.tree_snapshot([new_hal])[str(new_hal)]
assert set(after) == set(tree)
assert [n for n in tree if tree[n] != after[n]] == ['src/low_power.rs']
sources.update({str(new_hal / name): digest for name, digest in after.items()})
for p in [Path(__file__), prior / 'validation.json', HERE / 'hooks-v3/validation.json', HERE / 'irq-review-v1/findings.json']:
    sources[str(p)] = pm.sha(p)
pm.ensure_snapshot(sources)
pm.write_json(out / 'sources.json', sources)
pm.write_json(out / 'validation.json', dict(completed=True, integrated=False, hil='not-run',
    scope='HAL preparation only; H5 RTC non-secure vector selection corrected', chips=record['chips'],
    pac=record['pac'], hal=str(new_hal),
    sources=dict(path=str(out / 'sources.json'), sha256=pm.sha(out / 'sources.json'), files=len(sources))))
print('Prepared H5 RTC vector correction; PAC remains shared')
