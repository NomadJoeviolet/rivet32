"""Retain the typed H543/H553 PWR API; reuse the unchanged staged PAC."""
from pathlib import Path
import json
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'xtask/scripts'))
import peripheral_matrix as pm

prior = HERE / 'stage-v1'
out = HERE / 'stage-v2'
out.mkdir(exist_ok=False)
record = json.loads((prior / 'validation.json').read_bytes())
sources = json.loads(Path(record['sources']['path']).read_bytes())
pm.ensure_snapshot(sources)
old_hal = prior / 'embassy-stm32'
new_hal = out / 'embassy-stm32'
tree = pm.tree_snapshot([old_hal])[str(old_hal)]
for name in tree:
    p = new_hal / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(old_hal / name, p)
p = new_hal / 'src/low_power.rs'
s = p.read_text(encoding='utf-8')
old = '#[cfg(all(stm32h5, not(any(stm32h5_47a, stm32h5_47c))))]'
assert s.count(old) == 1
s = s.replace(old, '#[cfg(all(stm32h5, not(stm32h5_47a)))]')
old = '#[cfg(any(stm32h5_47a, stm32h5_47c))]\n        crate::pac::PWR.pmcr().modify(|v| {'
assert s.count(old) == 1
s = s.replace(old, '#[cfg(stm32h5_47a)]\n        crate::pac::PWR.pmcr().modify(|v| {')
p.write_text(s, encoding='utf-8', newline='\n')
after = pm.tree_snapshot([new_hal])[str(new_hal)]
assert set(after) == set(tree)
assert [n for n in tree if tree[n] != after[n]] == ['src/low_power.rs']
sources.update({str(new_hal / name): digest for name, digest in after.items()})
for p in [Path(__file__), prior / 'validation.json', HERE / 'hooks-v2/validation.json']:
    sources[str(p)] = pm.sha(p)
pm.ensure_snapshot(sources)
pm.write_json(out / 'sources.json', sources)
pm.write_json(out / 'validation.json', dict(completed=True, integrated=False, hil='not-run',
    scope='HAL preparation only; H543/H553 typed PWR API preserved', chips=record['chips'],
    pac=str(prior / 'stm32-metapac'), hal=str(new_hal),
    sources=dict(path=str(out / 'sources.json'), sha256=pm.sha(out / 'sources.json'), files=len(sources))))
print('Prepared corrected HAL; unchanged PAC reused without another copy')
