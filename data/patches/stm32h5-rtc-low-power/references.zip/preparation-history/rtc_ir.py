"""Exact H5 RTC inputs for the existing Embassy v3 driver; no chip aliases."""
from copy import deepcopy
from pathlib import Path
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FAMILIES = ('STM32H543', 'STM32H553', 'STM32H5E4', 'STM32H5E5', 'STM32H5F4', 'STM32H5F5')

# (register, field, enum name, [(variant, ST macro, macro shift, encoding)])
# KEY encodings are checked separately against actual ST write-protection macros.
ENUMS = [
    ('TR', 'PM', 'AMPM', [('AM', 'RTC_HOURFORMAT12_AM', 0, 0), ('PM', 'RTC_HOURFORMAT12_PM', 0, 1)]),
    ('CR', 'FMT', 'FMT', [('TwentyFourHour', 'RTC_HOURFORMAT_24', 6, 0), ('AMPM', 'RTC_HOURFORMAT_12', 6, 1)]),
    ('CR', 'POL', 'POL', [('High', 'RTC_OUTPUT_POLARITY_HIGH', 20, 0), ('Low', 'RTC_OUTPUT_POLARITY_LOW', 20, 1)]),
    ('CR', 'OSEL', 'OSEL', [('Disabled', 'RTC_OUTPUT_DISABLE', 21, 0), ('AlarmA', 'RTC_OUTPUT_ALARMA', 21, 1),
                          ('AlarmB', 'RTC_OUTPUT_ALARMB', 21, 2), ('Wakeup', 'RTC_OUTPUT_WAKEUP', 21, 3)]),
    ('CR', 'TAMPALRM_TYPE', 'TAMPALRM_TYPE', [('PushPull', 'RTC_OUTPUT_TYPE_PUSHPULL', 30, 0),
                                          ('OpenDrain', 'RTC_OUTPUT_TYPE_OPENDRAIN', 30, 1)]),
    ('CR', 'WUCKSEL', 'WUCKSEL', [('Div16', 'RTC_WAKEUPCLOCK_RTCCLK_DIV16', 0, 0),
                                ('Div8', 'RTC_WAKEUPCLOCK_RTCCLK_DIV8', 0, 1),
                                ('Div4', 'RTC_WAKEUPCLOCK_RTCCLK_DIV4', 0, 2),
                                ('Div2', 'RTC_WAKEUPCLOCK_RTCCLK_DIV2', 0, 3),
                                ('ClockSpare', 'RTC_WAKEUPCLOCK_CK_SPRE_16BITS', 0, 4),
                                ('ClockSpareWithOffset', 'RTC_WAKEUPCLOCK_CK_SPRE_17BITS', 0, 6)]),
    ('CALR', 'CALW8', 'CALW8', [('Default', 'RTC_SMOOTHCALIB_PERIOD_32SEC', 14, 0),
                             ('EightSeconds', 'RTC_SMOOTHCALIB_PERIOD_8SEC', 14, 1)]),
    ('CALR', 'CALW16', 'CALW16', [('Default', 'RTC_SMOOTHCALIB_PERIOD_32SEC', 13, 0),
                               ('SixteenSeconds', 'RTC_SMOOTHCALIB_PERIOD_16SEC', 13, 1)]),
    ('CALR', 'CALP', 'CALP', [('NoChange', 'RTC_SMOOTHCALIB_PLUSPULSES_RESET', 15, 0),
                           ('IncreaseFreq', 'RTC_SMOOTHCALIB_PLUSPULSES_SET', 15, 1)]),
    ('SCR', 'CWUTF', 'CALRF', [('Clear', 'RTC_SCR_CWUTF', 2, 1)]),
    ('WPR', 'KEY', 'KEY', [('Activate', None, 0, 0xff), ('Deactivate1', None, 0, 0xca), ('Deactivate2', None, 0, 0x53)]),
]


def original(family):
    if family not in FAMILIES:
        raise ValueError('An exact supported family is required')
    if family in FAMILIES[:2]:
        path = ROOT / f'data/patches/stm32h5-47c-pac/registers/rtc_{family.lower()}_47c.json'
        return json.loads(path.read_bytes())
    with zipfile.ZipFile(ROOT / 'data/patches/stm32h5-47a-pac/inputs.zip') as z:
        return json.loads(z.read(f'registers/rtc_{family.lower()}_47a.json'))


def normalize_names(native):
    result = {}
    for key, value in deepcopy(native).items():
        if key.startswith('fieldset/RTC_'):
            key = 'fieldset/' + key.removeprefix('fieldset/RTC_')
        if key.startswith('block/'):
            for item in value['items']:
                if 'fieldset' in item:
                    item['fieldset'] = item['fieldset'].removeprefix('RTC_')
        if key in result:
            raise ValueError('Fieldset rename collision')
        result[key] = value
    return result


def adapt(native, constants):
    result = normalize_names(native)
    for register, name, enum, variants in ENUMS:
        field = next(f for f in result['fieldset/' + register]['fields'] if f['name'] == name)
        prefix = f'RTC_{register}_{name}'
        if constants[prefix + '_Pos'] != field['bit_offset'] or constants[prefix + '_Msk'] != ((1 << field['bit_size']) - 1) << field['bit_offset']:
            raise ValueError('Exact CMSIS field layout mismatch: ' + prefix)
        for _, macro, shift, value in variants:
            if macro and constants[macro] != value << shift:
                raise ValueError('ST encoding mismatch: ' + macro)
            if value >= 1 << field['bit_size']:
                raise ValueError('Enum exceeds exact field width')
        if 'enum' in field or 'enum/' + enum in result:
            raise ValueError('Refusing to replace existing enum')
        field['enum'] = enum
        result['enum/' + enum] = dict(bit_size=field['bit_size'], variants=[dict(name=n, value=v) for n, _, _, v in variants])
    return result
