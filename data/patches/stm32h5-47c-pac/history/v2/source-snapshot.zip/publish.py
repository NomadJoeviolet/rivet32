"""Publish a completed independent PAC snapshot; root vendor is never touched."""
import argparse
import json
from pathlib import Path
import shutil

import audit_outputs
import generate
import provenance
import verify

HERE=Path(__file__).resolve().parent


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--workspace",type=Path);ap.add_argument("--output",type=Path)
    args=ap.parse_args();root=(args.workspace or provenance.workspace()).resolve();output=(args.output or root/"target/h5-47c-pac-generation").resolve()
    destination=root/"data/patches/stm32h5-47c-pac"
    if destination.exists() and any(destination.iterdir()):raise ValueError("Refusing to overwrite an existing published snapshot")
    with generate.output_lock(output):
        result=json.loads((output/"validation.json").read_text(encoding="utf-8"))
        if not result.get("completed") or result.get("deterministic_replays")!=2 or len(result.get("arm_checks",[]))!=14:
            raise ValueError("Complete deterministic 14-part validation is required before publishing")
        if verify.tree_hash(output/"build/stm32-metapac")!=result["generated_files"]:raise ValueError("PAC changed since validation")
        provenance.verify(root)
        audit_outputs.audit(root,output)
        files={}
        for p in HERE.glob("*.py"):files[p.name]=p
        for name in ("README.md","PLAN.md","sources.json"):files[name]=HERE/name
        for folder in ("sources","fixtures"):
            for p in (HERE/folder).rglob("*"):
                if p.is_file() and "__pycache__" not in p.parts:files[p.relative_to(HERE).as_posix()]=p
        for source,folder in ((output/"build/data/chips","chips"),(output/"build/data/registers","registers"),(output/"build/stm32-metapac","generated-pac")):
            for p in source.rglob("*"):
                if p.is_file():files[folder+"/"+p.relative_to(source).as_posix()]=p
        for name in ("generation.json","validation.json","register-evidence.json","ip-reuse.json","derived-ips.json","api-diff.json","selected-versions.json"):
            files[name]=output/name
        hashes={}
        for name,path in sorted(files.items()):
            if path.suffix.lower() in (".pdf",".exe",".rlib",".o",".pyc"):raise ValueError("Unexpected non-source publication artifact: "+name)
            raw=path.read_bytes();dest=destination/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            hashes[name]=provenance.digest(raw)
        generate.dump(destination/"manifest.json",{"schema":1,"completed":True,"hal_integrated":False,"files":hashes,
            "sources_lock_sha256":result["sources_lock_sha256"],"chips":14,"pac_sha256":result["generated_files"]})
        print("Published",len(hashes),"files to",destination)


if __name__=="__main__":main()
